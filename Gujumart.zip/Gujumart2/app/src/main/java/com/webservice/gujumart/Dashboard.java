package com.webservice.gujumart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    //Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        //-------Hooks---------------------------------
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       // toolbar = findViewById(R.id.toolbar);

        //-----------ToolBar----------------------------
       // setSupportActionBar(toolbar);
       // setSupportActionBar(toolbar);

        //-----------------Navigation Drawer Menu-------

      //  navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.Navigation_drawer_open, R.string.Navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    public void onBackPressed(){

        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.nav_home:
                 break;
            case R.id.nav_deliveryAddress:
                Intent intent = new Intent(Dashboard.this, DeliveryAddress.class);
                startActivity(intent);
                break;

            case R.id.nav_myOrder:
                Intent intentTwo = new Intent(Dashboard.this, yourOrders.class);
                startActivity(intentTwo);
                break;

            case R.id.nav_myprofile:
                Intent intentThree = new Intent(Dashboard.this, MyProfile.class);
                startActivity(intentThree);
                break;

            case R.id.nav_login:
                Intent intentfour = new Intent(Dashboard.this, Login.class);
                startActivity(intentfour);
                break;

            case R.id.nav_Logout:

                Snackbar.make(coordinatorLayout, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                break;

            case R.id.nav_contact_us:
                Intent intentfive = new Intent(Dashboard.this, ContactUs.class);
                startActivity(intentfive);
                break;

            case R.id.nav_rate:
                break;

            case R.id.nav_share:
                break;

        }

        return true;
    }
}
